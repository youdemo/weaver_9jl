package higer.exchange;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Collection;

import org.json.JSONArray;
import org.json.JSONObject;

import microsoft.exchange.webservices.data.Appointment;
import microsoft.exchange.webservices.data.ConflictResolutionMode;
import microsoft.exchange.webservices.data.ExchangeCredentials;
import microsoft.exchange.webservices.data.ExchangeService;
import microsoft.exchange.webservices.data.ExchangeVersion;
import microsoft.exchange.webservices.data.MessageBody;
import microsoft.exchange.webservices.data.TimeZoneDefinition;
import microsoft.exchange.webservices.data.WebCredentials;

public class Test {

	public static void main(String[] args) throws Exception {
//	  String aa="{\"taskDetl\":[{\"startDate\":\"2019/05/23\",\"endDate\":\"2019/06/30\",\"projectName\":\"KLQ6127双前档大型公路产品开发项目\",\"taskName\":\"完善车型BOM至小批量\",\"url\":\"http://windchillweb.klsz.com/Windchill/servlet/TypeBasedIncludeServlet?oid=OR%3Awt.projmgmt.execution.ProjectActivity%3A14567422966&u8=1\"},{\"startDate\":\"2019/05/23\",\"endDate\":\"2019/06/30\",\"projectName\":\"KLQ6127双前档大型公路产品开发项目\",\"taskName\":\"产品确认\",\"url\":\"http://windchillweb.klsz.com/Windchill/servlet/TypeBasedIncludeServlet?oid=OR%3Awt.projmgmt.execution.ProjectActivity%3A14567423032&u8=1\"},{\"startDate\":\"2019/04/11\",\"endDate\":\"2019/06/30\",\"projectName\":\"KLQ6127双前档大型公路产品开发项目\",\"taskName\":\"开发阶段结束\",\"url\":\"http://windchillweb.klsz.com/Windchill/servlet/TypeBasedIncludeServlet?oid=OR%3Awt.projmgmt.execution.Milestone%3A14437797452&u8=1\"}],\"taskNumber\":3}";
//	  JSONObject json = new JSONObject(aa);
//	  JSONArray ja = json.getJSONArray("taskDetl");
//	  for(int i=0;i<ja.length();i++) {
//		  JSONObject jo = ja.getJSONObject(i);
//		  String startDate = jo.getString("startDate");
//		  String endDate = jo.getString("endDate");
//		  String projectName = jo.getString("projectName");
//		  String taskName = jo.getString("taskName");
//		  String url = jo.getString("url");
//		  System.out.println(taskName);
//	  }
//	  String taskNumber = json.getString("taskNumber");
String aaa= "<result>{&quot;taskDetl&quot;:[],&quot;taskNumber&quot;:0}</result>";
int  start=aaa.indexOf("<result>")+8;
int  end=aaa.indexOf("</result>");
	  System.out.println(start);
	  System.out.println(end);
	  System.out.println(aaa.substring(start,58));

	}
	
	public static void sendRc() throws Exception {
		SimpleDateFormat  aa = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
		ExchangeCredentials credentials = new WebCredentials("chengz", "cgz1212");    
		service.setCredentials(credentials);
		service.setUrl(new URI("https://mail.higer.com/ews/Exchange.asmx"));
		service.setCredentials(credentials);
		service.setTraceEnabled(true);
		Appointment appointment = new Appointment(service);
		// Set the properties on the appointment object to create the appointment.
		appointment.setSubject("test123");
		appointment.setBody(MessageBody.getMessageBodyFromText("test"));
		appointment.setStart(aa.parse("2019-06-03 15:20:12"));
		appointment.setEnd(aa.parse("2019-06-03 17:20:12"));
		appointment.setLocation("123");
		appointment.setLocation("会议位置");
		Collection<TimeZoneDefinition> t = service.getServerTimeZones();
        TimeZoneDefinition tf = null;
        for (TimeZoneDefinition timeZoneDefinition : t) {
            tf = timeZoneDefinition;
        }
		appointment.setStartTimeZone(tf);
		//appointment.getResources().add("会议资源账号，如：meetingroom@company.com");
	 
		appointment.getRequiredAttendees().add("chengz@higer.com");
		//appointment.getOptionalAttendees().add("可选参加的员工的账号");
		appointment.save();
		appointment.update(ConflictResolutionMode.AutoResolve);

		
	}
	

}
