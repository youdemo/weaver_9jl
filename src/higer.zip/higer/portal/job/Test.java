package higer.portal.job;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Test {

	public static void main(String[] args) {
		String result = "{\"success\":true,\"data\":[{\"functionType\":\"10\",\"userId\":\"chenbin2\",\"subsystemCode\":\"ITILW\",\"subsystemName\":\"信息服务\",\"subsystemEnName\":\"ITILW\",\"SeqNo\":109,\"url\":\"http://ihiger.klsz.com/Pages/ERPMain.aspx?subSystemId=ITILW\",\"websiteType\":\"portal\",\"diffType\":\"DEL\"}]}";
		try {
			JSONObject json = new JSONObject(result);
			String success = json.getString("success");
			System.out.println(success);
			JSONArray ja = json.getJSONArray("data");
			String functionType = "";
			String userId = "";
			String subsystemCode = "";
			String subsystemName = "";
			String SeqNo = "";
			String url = "";
			String websiteType = "";
			String diffType = "";
			for(int i=0;i<ja.length();i++) {
				JSONObject jo = ja.getJSONObject(i);
				functionType = jo.getString("functionType");
				userId = jo.getString("userId");
				subsystemCode = jo.getString("subsystemCode");
				subsystemName = jo.getString("subsystemName");
				SeqNo = jo.getString("SeqNo");
				url = jo.getString("url");
				websiteType = jo.getString("websiteType");
				diffType = jo.getString("diffType");
				System.out.println(functionType);
			}
			System.out.println(ja.length());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
